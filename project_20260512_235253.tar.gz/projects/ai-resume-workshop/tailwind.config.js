/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#1677FF',
        'primary-light': '#E6F0FF',
        border: '#E8ECF1',
        bg: '#F5F6F8',
        card: '#FFFFFF',
        'text-main': '#1A1A1A',
        'text-secondary': '#666',
        'text-muted': '#999',
      },
    },
  },
  plugins: [],
};
