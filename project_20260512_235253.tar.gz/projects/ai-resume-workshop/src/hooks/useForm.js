import { useState, useEffect } from 'react';
import { saveDraft } from '../utils/storage';

const defaultForm = {
  name: '',
  gender: '',
  age: '',
  phone: '',
  email: '',
  location: '',
  position: '',
  salary: '',
  summary: '',
  workExps: [],
  edus: [],
  projectExps: [],
  skills: '',
};

const generateId = () => Math.random().toString(36).substr(2, 9);

export default function useForm(initialData = {}) {
  const [form, setForm] = useState({ ...defaultForm, ...initialData });

  const updateForm = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
    debouncedSave({ ...form, [field]: value });
  };

  const resetForm = (data = defaultForm) => {
    setForm({ ...defaultForm, ...data });
  };

  const updateWork = (id, field, value) => {
    setForm(prev => ({
      ...prev,
      workExps: prev.workExps.map(exp =>
        exp.id === id ? { ...exp, [field]: value } : exp
      ),
    }));
  };

  const addWork = () => {
    setForm(prev => ({
      ...prev,
      workExps: [...prev.workExps, {
        id: generateId(),
        company: '',
        position: '',
        startDate: '',
        endDate: '',
        description: '',
      }],
    }));
  };

  const removeWork = (id) => {
    setForm(prev => ({
      ...prev,
      workExps: prev.workExps.filter(exp => exp.id !== id),
    }));
  };

  const updateEdu = (id, field, value) => {
    setForm(prev => ({
      ...prev,
      edus: prev.edus.map(edu =>
        edu.id === id ? { ...edu, [field]: value } : edu
      ),
    }));
  };

  const addEdu = () => {
    setForm(prev => ({
      ...prev,
      edus: [...prev.edus, {
        id: generateId(),
        school: '',
        major: '',
        degree: '本科',
        startDate: '',
        endDate: '',
      }],
    }));
  };

  const removeEdu = (id) => {
    setForm(prev => ({
      ...prev,
      edus: prev.edus.filter(edu => edu.id !== id),
    }));
  };

  const updateProject = (id, field, value) => {
    setForm(prev => ({
      ...prev,
      projectExps: prev.projectExps.map(proj =>
        proj.id === id ? { ...proj, [field]: value } : proj
      ),
    }));
  };

  const addProject = () => {
    setForm(prev => ({
      ...prev,
      projectExps: [...prev.projectExps, {
        id: generateId(),
        name: '',
        role: '',
        startDate: '',
        endDate: '',
        description: '',
      }],
    }));
  };

  const removeProject = (id) => {
    setForm(prev => ({
      ...prev,
      projectExps: prev.projectExps.filter(proj => proj.id !== id),
    }));
  };

  let saveTimer = null;
  const debouncedSave = (data) => {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      const name = data.name || '未命名简历';
      saveDraft({ name: name.substring(0, 20), data, date: new Date().toLocaleString() });
    }, 2000);
  };

  return {
    form,
    updateForm,
    updateWork,
    addWork,
    removeWork,
    updateEdu,
    addEdu,
    removeEdu,
    updateProject,
    addProject,
    removeProject,
    resetForm,
  };
}
