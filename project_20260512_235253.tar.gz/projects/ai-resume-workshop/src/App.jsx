import { useState } from 'react';
import EditorPanel from './components/EditorPanel';
import PreviewPanel from './components/PreviewPanel';
import RewriteModal from './components/RewriteModal';
import Toast from './components/Toast';
import useForm from './hooks/useForm';
import { parseRawText } from './utils/parse';

export default function App() {
  const { form, updateForm, updateWork, addWork, removeWork, updateEdu, addEdu, removeEdu, updateProject, addProject, removeProject, resetForm } = useForm();
  const [rewriteTarget, setRewriteTarget] = useState(null);
  const [toastMsg, setToastMsg] = useState('');

  const showToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 2000);
  };

  const handleParse = (raw) => {
    const parsed = parseRawText(raw);
    resetForm(parsed);
    showToast('解析完成，请检查各模块');
  };

  return (
    <div className="flex h-screen">
      <EditorPanel
        form={form}
        updateForm={updateForm}
        updateWork={updateWork}
        addWork={addWork}
        removeWork={removeWork}
        updateEdu={updateEdu}
        addEdu={addEdu}
        removeEdu={removeEdu}
        updateProject={updateProject}
        addProject={addProject}
        removeProject={removeProject}
        onParse={handleParse}
        onRewrite={(type, id) => setRewriteTarget({ type, id })}
      />
      <PreviewPanel form={form} />
      {rewriteTarget && (
        <RewriteModal
          target={rewriteTarget}
          form={form}
          updateWork={updateWork}
          updateProject={updateProject}
          onClose={() => setRewriteTarget(null)}
          showToast={showToast}
        />
      )}
      {toastMsg && <Toast message={toastMsg} />}
    </div>
  );
}
