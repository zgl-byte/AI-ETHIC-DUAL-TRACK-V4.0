import { Printer, Download } from 'lucide-react';

export default function PreviewPanel({ form }) {
  const isEmpty = !form.name && !form.phone && !form.email && 
                   form.workExps.length === 0 && form.edus.length === 0 &&
                   form.projectExps.length === 0;

  const handlePrint = () => window.print();

  const handleDownload = () => {
    const content = document.querySelector('.preview-paper')?.innerHTML;
    if (!content) return;
    
    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${form.name || '简历'}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif; font-size: 14px; line-height: 1.75; color: #1A1A1A; }
    .paper { width: 794px; min-height: 1123px; margin: 0 auto; padding: 60px 70px; background: #fff; }
    .name { font-size: 28px; font-weight: bold; margin-bottom: 12px; }
    .info { display: flex; gap: 16px; flex-wrap: wrap; color: #666; font-size: 13px; margin-bottom: 20px; }
    .info span { display: flex; align-items: center; gap: 4px; }
    .section { margin-top: 24px; }
    .section-title { font-size: 14px; font-weight: bold; border-bottom: 1.5px solid #1A1A1A; padding-bottom: 4px; margin-bottom: 12px; }
    .summary { color: #444; font-size: 13px; }
    .exp-item { margin-bottom: 16px; }
    .exp-header { display: flex; justify-content: space-between; margin-bottom: 6px; }
    .exp-company { font-weight: 600; }
    .exp-date { color: #999; font-size: 12px; }
    .exp-desc { color: #444; font-size: 13px; white-space: pre-wrap; }
    .edu-row { display: flex; justify-content: space-between; margin-bottom: 8px; }
    .skills { color: #444; font-size: 13px; }
    @media print { body { background: white; } }
  </style>
</head>
<body>
  <div class="paper">
    ${form.name ? `<div class="name">${form.name}</div>` : ''}
    <div class="info">
      ${form.gender ? `<span>${form.gender}</span>` : ''}
      ${form.age ? `<span>${form.age}岁</span>` : ''}
      ${form.phone ? `<span>📱 ${form.phone}</span>` : ''}
      ${form.email ? `<span>✉️ ${form.email}</span>` : ''}
      ${form.location ? `<span>📍 ${form.location}</span>` : ''}
    </div>
    
    ${form.position || form.salary ? `
    <div class="section">
      <div class="section-title">求职意向</div>
      <div class="summary">
        ${form.position ? `期望职位：${form.position}` : ''}
        ${form.salary ? ` | 期望薪资：${form.salary}` : ''}
      </div>
    </div>` : ''}
    
    ${form.summary ? `
    <div class="section">
      <div class="section-title">个人简介</div>
      <div class="summary">${form.summary}</div>
    </div>` : ''}
    
    ${form.workExps.length > 0 ? `
    <div class="section">
      <div class="section-title">工作经历</div>
      ${form.workExps.map(exp => `
        <div class="exp-item">
          <div class="exp-header">
            <span class="exp-company">${exp.company || '公司名称'}</span>
            <span class="exp-date">${exp.startDate || ''} - ${exp.endDate || ''}</span>
          </div>
          <div class="exp-desc">${exp.position || '职位'}：${exp.description || ''}</div>
        </div>
      `).join('')}
    </div>` : ''}
    
    ${form.projectExps.length > 0 ? `
    <div class="section">
      <div class="section-title">项目经历</div>
      ${form.projectExps.map(proj => `
        <div class="exp-item">
          <div class="exp-header">
            <span class="exp-company">${proj.name || '项目名称'}</span>
            <span class="exp-date">${proj.startDate || ''} - ${proj.endDate || ''}</span>
          </div>
          <div class="exp-desc">${proj.role || '角色'}：${proj.description || ''}</div>
        </div>
      `).join('')}
    </div>` : ''}
    
    ${form.edus.length > 0 ? `
    <div class="section">
      <div class="section-title">教育经历</div>
      ${form.edus.map(edu => `
        <div class="edu-row">
          <span>${edu.school || '学校'} - ${edu.major || '专业'}</span>
          <span>${edu.degree || '学历'} | ${edu.startDate || ''} - ${edu.endDate || ''}</span>
        </div>
      `).join('')}
    </div>` : ''}
    
    ${form.skills ? `
    <div class="section">
      <div class="section-title">专业技能</div>
      <div class="skills">${form.skills}</div>
    </div>` : ''}
  </div>
</body>
</html>`;

    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${form.name || '简历'}_${Date.now()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isEmpty) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-100 preview-area">
        <div className="text-center text-gray-400">
          <div className="text-6xl mb-4">📄</div>
          <p className="text-lg">开始编辑左侧内容</p>
          <p className="text-sm mt-2">简历预览将在这里显示</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-auto bg-gray-200 p-8 preview-area">
      <div className="flex justify-end gap-2 mb-4 sticky top-0 z-10">
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 shadow-sm"
        >
          <Printer size={16} />
          打印
        </button>
        <button
          onClick={handleDownload}
          className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 shadow-sm"
        >
          <Download size={16} />
          导出 HTML
        </button>
      </div>

      <div className="flex justify-center">
        <div className="preview-paper">
          {/* 头部信息 */}
          {form.name && (
            <div className="text-center mb-4">
              <h1 className="text-[28px] font-bold tracking-wide">{form.name}</h1>
            </div>
          )}
          
          <div className="flex justify-center gap-4 text-[13px] text-gray-600 mb-6 flex-wrap">
            {form.gender && <span>{form.gender}</span>}
            {form.age && <span>{form.age}岁</span>}
            {form.phone && <span>📱 {form.phone}</span>}
            {form.email && <span>✉️ {form.email}</span>}
            {form.location && <span>📍 {form.location}</span>}
          </div>

          {/* 求职意向 */}
          {(form.position || form.salary) && (
            <div className="mb-6">
              <div className="section-title">求职意向</div>
              <div className="text-[13px] text-gray-600">
                {form.position && <span>期望职位：{form.position}</span>}
                {form.salary && <span className="ml-4">期望薪资：{form.salary}</span>}
              </div>
            </div>
          )}

          {/* 个人简介 */}
          {form.summary && (
            <div className="mb-6">
              <div className="section-title">个人简介</div>
              <div className="text-[13px] text-gray-600 leading-relaxed">{form.summary}</div>
            </div>
          )}

          {/* 工作经历 */}
          {form.workExps.length > 0 && (
            <div className="mb-6">
              <div className="section-title">工作经历</div>
              {form.workExps.map((exp, idx) => (
                <div key={exp.id} className="mb-4">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="font-semibold">{exp.company || '公司名称'}</span>
                    <span className="text-[12px] text-gray-400">
                      {exp.startDate || ''} - {exp.endDate || ''}
                    </span>
                  </div>
                  <div className="text-[12px] text-primary mb-2">{exp.position || '职位'}</div>
                  <div className="text-[13px] text-gray-600 whitespace-pre-wrap leading-relaxed">
                    {exp.description || ''}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* 项目经历 */}
          {form.projectExps.length > 0 && (
            <div className="mb-6">
              <div className="section-title">项目经历</div>
              {form.projectExps.map((proj) => (
                <div key={proj.id} className="mb-4">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="font-semibold">{proj.name || '项目名称'}</span>
                    <span className="text-[12px] text-gray-400">
                      {proj.startDate || ''} - {proj.endDate || ''}
                    </span>
                  </div>
                  <div className="text-[12px] text-primary mb-2">{proj.role || '角色'}</div>
                  <div className="text-[13px] text-gray-600 whitespace-pre-wrap leading-relaxed">
                    {proj.description || ''}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* 教育经历 */}
          {form.edus.length > 0 && (
            <div className="mb-6">
              <div className="section-title">教育经历</div>
              {form.edus.map((edu) => (
                <div key={edu.id} className="flex justify-between items-baseline mb-2">
                  <span className="font-semibold">{edu.school || '学校'}</span>
                  <span className="text-[12px] text-gray-500">
                    {edu.degree || '学历'} | {edu.startDate || ''} - {edu.endDate || ''}
                  </span>
                </div>
              ))}
              {form.edus.map((edu) => (
                edu.major && (
                  <div key={`major-${edu.id}`} className="text-[13px] text-gray-600">
                    {edu.major}
                  </div>
                )
              ))}
            </div>
          )}

          {/* 专业技能 */}
          {form.skills && (
            <div className="mb-6">
              <div className="section-title">专业技能</div>
              <div className="text-[13px] text-gray-600 leading-relaxed">
                {form.skills.split(/[\/\\,，、]/).filter(s => s.trim()).map((skill, i) => (
                  <span key={i} className="inline-block bg-gray-100 px-2 py-0.5 rounded text-[12px] mr-2 mb-1">
                    {skill.trim()}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
