import { useState, useEffect } from 'react';
import { History, X } from 'lucide-react';
import { getDrafts, deleteDraft } from '../utils/storage';

export default function DraftManager({ onLoad }) {
  const [drafts, setDrafts] = useState(getDrafts());
  const [open, setOpen] = useState(false);

  const refresh = () => setDrafts(getDrafts());

  useEffect(() => {
    refresh();
    const timer = setInterval(refresh, 2000);
    return () => clearInterval(timer);
  }, []);

  const handleDelete = (id) => {
    const updated = deleteDraft(id);
    setDrafts(updated);
  };

  return (
    <details className="text-sm" open={open} onToggle={e => setOpen(e.target.open)}>
      <summary className="cursor-pointer font-semibold text-text-secondary flex items-center gap-1 mb-2">
        <History size={14} />
        草稿箱 ({drafts.length})
      </summary>
      <div className="flex flex-col gap-2 max-h-40 overflow-y-auto">
        {drafts.length === 0 && <span className="text-xs text-text-muted">暂无草稿</span>}
        {drafts.map(d => (
          <div key={d.id} className="flex items-center justify-between bg-white border border-border rounded-lg px-3 py-2 text-xs">
            <span className="cursor-pointer hover:text-primary flex-1" onClick={() => onLoad && onLoad(d.data)}>
              {d.name} · {d.date}
            </span>
            <button onClick={() => handleDelete(d.id)} className="p-0.5 rounded hover:bg-red-50 text-gray-400 hover:text-red-500">
              <X size={12} />
            </button>
          </div>
        ))}
      </div>
    </details>
  );
}
