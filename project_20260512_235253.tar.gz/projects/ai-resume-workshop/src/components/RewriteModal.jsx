import { Sparkles, X } from 'lucide-react';

export default function RewriteModal({ target, form, updateWork, updateProject, onClose, showToast }) {
  const { type, id } = target;
  let originalText = '';
  if (type === 'work') originalText = form.workExps.find(e => e.id === id)?.description || '';
  if (type === 'project') originalText = form.projectExps.find(e => e.id === id)?.description || '';

  const apply = (style) => {
    let newText = originalText;
    if (style === 'professional') newText = originalText.replace(/负责/g, '主导').replace(/参与/g, '深度参与');
    if (style === 'concise') newText = originalText.substring(0, Math.floor(originalText.length * 0.6)) + '...';
    if (style === 'result') newText = originalText.replace(/提升/g, '达成').replace(/优化/g, '超额优化').replace(/降低/g, '缩减');
    if (type === 'work') updateWork(id, 'description', newText);
    if (type === 'project') updateProject(id, 'description', newText);
    showToast('已应用改写');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center modal-overlay" onClick={onClose}>
      <div className="bg-white rounded-2xl p-6 w-[460px] max-w-[90vw] shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold flex items-center gap-2"><Sparkles size={20} color="#1677FF" /> AI改写</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
        </div>
        <p className="text-xs text-gray-400 mb-1">原文</p>
        <p className="text-xs bg-gray-50 p-3 rounded-lg mb-4 text-gray-600">{originalText.substring(0, 100)}…</p>
        <button onClick={() => apply('professional')} className="w-full text-left p-3 border rounded-lg mb-2 hover:border-primary hover:bg-primary-light transition">
          <span className="font-semibold text-sm">更专业</span>
          <p className="text-xs text-gray-500 mt-1">动宾结构，主动交付</p>
        </button>
        <button onClick={() => apply('concise')} className="w-full text-left p-3 border rounded-lg mb-2 hover:border-primary hover:bg-primary-light transition">
          <span className="font-semibold text-sm">更精炼</span>
          <p className="text-xs text-gray-500 mt-1">压缩冗余，保留核心</p>
        </button>
        <button onClick={() => apply('result')} className="w-full text-left p-3 border rounded-lg hover:border-primary hover:bg-primary-light transition">
          <span className="font-semibold text-sm">更突出成果</span>
          <p className="text-xs text-gray-500 mt-1">数据说话，结果前置</p>
        </button>
      </div>
    </div>
  );
}
