import { X, Sparkles } from 'lucide-react';

export default function ExpItem({ onDelete, onRewrite, children }) {
  return (
    <div className="relative border border-border rounded-lg p-4 mb-3 bg-gray-50/50">
      <button onClick={onDelete} className="absolute top-2 right-2 p-1 rounded hover:bg-red-50 hover:text-red-500 text-gray-400">
        <X size={14} />
      </button>
      {onRewrite && (
        <button onClick={onRewrite} className="absolute top-2 right-8 p-1 rounded hover:bg-purple-50 text-purple-500">
          <Sparkles size={14} />
        </button>
      )}
      {children}
    </div>
  );
}
