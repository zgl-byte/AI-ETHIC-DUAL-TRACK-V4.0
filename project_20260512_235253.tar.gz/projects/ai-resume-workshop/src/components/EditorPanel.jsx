import { useState } from 'react';
import { User, Phone, Mail, MapPin, Briefcase, Banknote, FileText, Plus, ChevronDown } from 'lucide-react';
import SectionCard from './SectionCard';
import ExpItem from './ExpItem';
import ParseArea from './ParseArea';
import DraftManager from './DraftManager';

function InputField({ label, value, onChange, placeholder, icon: Icon }) {
  return (
    <div className="mb-3">
      <label className="block text-xs font-medium text-text-secondary mb-1 flex items-center gap-1">
        {Icon && <Icon size={12} />}
        {label}
      </label>
      <input
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
      />
    </div>
  );
}

function TextAreaField({ label, value, onChange, placeholder, rows = 4 }) {
  return (
    <div className="mb-3">
      <label className="block text-xs font-medium text-text-secondary mb-1">{label}</label>
      <textarea
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none transition resize-y"
      />
    </div>
  );
}

export default function EditorPanel({
  form,
  updateForm,
  updateWork, addWork, removeWork,
  updateEdu, addEdu, removeEdu,
  updateProject, addProject, removeProject,
  onParse,
  onRewrite,
}) {
  const [collapsed, setCollapsed] = useState({});

  const toggle = (key) => setCollapsed(prev => ({ ...prev, [key]: !prev[key] }));

  return (
    <div className="w-[420px] h-screen overflow-y-auto bg-bg p-4 editor-panel">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-lg font-bold text-text-main">AI 简历工坊</h1>
        <DraftManager />
      </div>

      {/* AI 解析区 */}
      <ParseArea onParse={onParse} />

      {/* 基础信息 */}
      <SectionCard
        title="基础信息"
        icon="User"
        collapsed={collapsed['basic']}
        onToggle={() => toggle('basic')}
      >
        <div className="grid grid-cols-2 gap-3">
          <InputField label="姓名" value={form.name} onChange={v => updateForm('name', v)} placeholder="张三" icon={User} />
          <InputField label="性别" value={form.gender} onChange={v => updateForm('gender', v)} placeholder="男/女" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <InputField label="年龄" value={form.age} onChange={v => updateForm('age', v)} placeholder="25" />
          <InputField label="手机" value={form.phone} onChange={v => updateForm('phone', v)} placeholder="13800138000" icon={Phone} />
        </div>
        <InputField label="邮箱" value={form.email} onChange={v => updateForm('email', v)} placeholder="example@email.com" icon={Mail} />
        <InputField label="所在城市" value={form.location} onChange={v => updateForm('location', v)} placeholder="北京" icon={MapPin} />
      </SectionCard>

      {/* 求职意向 */}
      <SectionCard
        title="求职意向"
        icon="Briefcase"
        collapsed={collapsed['target']}
        onToggle={() => toggle('target')}
      >
        <InputField label="期望职位" value={form.position} onChange={v => updateForm('position', v)} placeholder="前端工程师" icon={Briefcase} />
        <InputField label="期望薪资" value={form.salary} onChange={v => updateForm('salary', v)} placeholder="20-30K" icon={Banknote} />
        <TextAreaField
          label="个人简介"
          value={form.summary}
          onChange={v => updateForm('summary', v)}
          placeholder="简述您的核心竞争力和职业目标..."
          rows={3}
        />
      </SectionCard>

      {/* 工作经历 */}
      <SectionCard
        title="工作经历"
        icon="Building2"
        collapsed={collapsed['work']}
        onToggle={() => toggle('work')}
        extra={
          <button onClick={addWork} className="text-primary text-xs hover:underline flex items-center gap-0.5">
            <Plus size={12} /> 添加
          </button>
        }
      >
        {form.workExps.length === 0 && (
          <p className="text-xs text-text-muted text-center py-4">暂无工作经历，点击上方添加</p>
        )}
        {form.workExps.map((exp, idx) => (
          <ExpItem key={exp.id} onDelete={() => removeWork(exp.id)} onRewrite={() => onRewrite('work', exp.id)}>
            <div className="grid grid-cols-2 gap-3">
              <InputField label="公司名称" value={exp.company} onChange={v => updateWork(exp.id, 'company', v)} placeholder="公司名" />
              <InputField label="职位名称" value={exp.position} onChange={v => updateWork(exp.id, 'position', v)} placeholder="前端工程师" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <InputField label="开始时间" value={exp.startDate} onChange={v => updateWork(exp.id, 'startDate', v)} placeholder="2020.01" />
              <InputField label="结束时间" value={exp.endDate} onChange={v => updateWork(exp.id, 'endDate', v)} placeholder="至今" />
            </div>
            <TextAreaField
              label="工作描述"
              value={exp.description}
              onChange={v => updateWork(exp.id, 'description', v)}
              placeholder="• 负责...&#10;• 主导...&#10;• 达成..."
              rows={4}
            />
          </ExpItem>
        ))}
      </SectionCard>

      {/* 项目经历 */}
      <SectionCard
        title="项目经历"
        icon="Layers"
        collapsed={collapsed['project']}
        onToggle={() => toggle('project')}
        extra={
          <button onClick={addProject} className="text-primary text-xs hover:underline flex items-center gap-0.5">
            <Plus size={12} /> 添加
          </button>
        }
      >
        {form.projectExps.length === 0 && (
          <p className="text-xs text-text-muted text-center py-4">暂无项目经历，点击上方添加</p>
        )}
        {form.projectExps.map((exp, idx) => (
          <ExpItem key={exp.id} onDelete={() => removeProject(exp.id)} onRewrite={() => onRewrite('project', exp.id)}>
            <div className="grid grid-cols-2 gap-3">
              <InputField label="项目名称" value={exp.name} onChange={v => updateProject(exp.id, 'name', v)} placeholder="项目名" />
              <InputField label="项目角色" value={exp.role} onChange={v => updateProject(exp.id, 'role', v)} placeholder="前端开发" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <InputField label="开始时间" value={exp.startDate} onChange={v => updateProject(exp.id, 'startDate', v)} placeholder="2021.03" />
              <InputField label="结束时间" value={exp.endDate} onChange={v => updateProject(exp.id, 'endDate', v)} placeholder="至今" />
            </div>
            <TextAreaField
              label="项目描述"
              value={exp.description}
              onChange={v => updateProject(exp.id, 'description', v)}
              placeholder="• 项目背景...&#10;• 技术栈...&#10;• 核心成果..."
              rows={4}
            />
          </ExpItem>
        ))}
      </SectionCard>

      {/* 教育经历 */}
      <SectionCard
        title="教育经历"
        icon="GraduationCap"
        collapsed={collapsed['edu']}
        onToggle={() => toggle('edu')}
        extra={
          <button onClick={addEdu} className="text-primary text-xs hover:underline flex items-center gap-0.5">
            <Plus size={12} /> 添加
          </button>
        }
      >
        {form.edus.length === 0 && (
          <p className="text-xs text-text-muted text-center py-4">暂无教育经历，点击上方添加</p>
        )}
        {form.edus.map((edu) => (
          <ExpItem key={edu.id} onDelete={() => removeEdu(edu.id)}>
            <div className="grid grid-cols-2 gap-3">
              <InputField label="学校名称" value={edu.school} onChange={v => updateEdu(edu.id, 'school', v)} placeholder="学校名" />
              <InputField label="专业名称" value={edu.major} onChange={v => updateEdu(edu.id, 'major', v)} placeholder="计算机科学与技术" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <InputField label="学历" value={edu.degree} onChange={v => updateEdu(edu.id, 'degree', v)} placeholder="本科" />
              <InputField label="时间范围" value={`${edu.startDate} - ${edu.endDate}`} onChange={v => {
                const [s, e] = v.split(' - ');
                updateEdu(edu.id, 'startDate', s || '');
                updateEdu(edu.id, 'endDate', e || '');
              }} placeholder="2018 - 2022" />
            </div>
          </ExpItem>
        ))}
      </SectionCard>

      {/* 专业技能 */}
      <SectionCard
        title="专业技能"
        icon="Code"
        collapsed={collapsed['skills']}
        onToggle={() => toggle('skills')}
      >
        <TextAreaField
          label="技能清单"
          value={form.skills}
          onChange={v => updateForm('skills', v)}
          placeholder="React / Vue / TypeScript / Node.js / Git..."
          rows={3}
        />
      </SectionCard>

      <div className="h-8" />
    </div>
  );
}
