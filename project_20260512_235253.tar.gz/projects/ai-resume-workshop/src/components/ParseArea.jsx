import { useState } from 'react';
import { ClipboardPaste, Sparkles, FileText } from 'lucide-react';

const exampleText = '我叫张明，手机13800138000，邮箱zhang@qq.com，1998年出生。3年前端开发经验。在字节跳动担任高级前端工程师，负责抖音电商商家后台，把页面加载速度从4秒优化到1.2秒，搭建了组件库给团队复用。之前在美团做前端开发，参与小程序开发，DAU做到100万。本科华中科技大学计算机专业。期望职位前端开发工程师，期望城市北京，期望薪资20-30K。';

export default function ParseArea({ onParse }) {
  const [raw, setRaw] = useState('');

  const handleParse = () => {
    if (!raw.trim()) return alert('请先粘贴经历');
    onParse(raw);
  };

  return (
    <div className="bg-gradient-to-br from-primary-light/50 to-blue-50 rounded-xl p-4 border border-dashed border-blue-300 mb-4">
      <div className="flex items-center gap-2 text-primary font-semibold text-sm mb-2">
        <ClipboardPaste size={16} />
        粘贴经历，自动填充
      </div>
      <textarea
        value={raw}
        onChange={e => setRaw(e.target.value)}
        rows={5}
        className="w-full bg-white border border-blue-200 rounded-lg p-3 text-sm resize-y focus:border-primary focus:ring-1 focus:ring-primary"
        placeholder="把整段经历复制到这里，AI会自动拆分到各个模块…"
      />
      <div className="flex gap-2 mt-2">
        <button onClick={handleParse} className="flex items-center gap-1 bg-primary text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-blue-700">
          <Sparkles size={14} />
          解析并填充
        </button>
        <button onClick={() => setRaw(exampleText)} className="flex items-center gap-1 bg-white border border-border px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
          <FileText size={14} />
          填入示例
        </button>
      </div>
    </div>
  );
}
