import { ChevronDown } from 'lucide-react';
import * as LucideIcons from 'lucide-react';

export default function SectionCard({ title, icon, children, collapsed, onToggle, extra }) {
  const IconComponent = LucideIcons[icon] || LucideIcons.FileText;
  return (
    <div className={`bg-card rounded-xl shadow-sm overflow-hidden ${collapsed ? 'collapsed' : ''}`}>
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-gray-50/50 cursor-pointer select-none" onClick={onToggle}>
        <div className="flex items-center gap-2 font-semibold text-sm text-text-main">
          <IconComponent size={18} color="#1677FF" />
          {title}
        </div>
        <div className="flex items-center gap-2">
          {extra}
          <ChevronDown size={16} className={`transition-transform ${collapsed ? '-rotate-90' : ''}`} />
        </div>
      </div>
      {!collapsed && <div className="p-4">{children}</div>}
    </div>
  );
}
