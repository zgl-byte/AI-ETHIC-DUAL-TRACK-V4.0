const STORAGE_KEY = 'resume_drafts';

export function saveDraft(draft) {
  try {
    const drafts = getDrafts();
    const existingIndex = drafts.findIndex(d => d.name === draft.name);
    
    if (existingIndex >= 0) {
      drafts[existingIndex] = { ...draft, id: drafts[existingIndex].id, updatedAt: new Date().toISOString() };
    } else {
      drafts.unshift({ ...draft, id: Date.now().toString(), updatedAt: new Date().toISOString() });
    }
    
    // 最多保留10份草稿
    const trimmedDrafts = drafts.slice(0, 10);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmedDrafts));
    return trimmedDrafts;
  } catch (e) {
    console.warn('保存草稿失败:', e);
    return [];
  }
}

export function getDrafts() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.warn('读取草稿失败:', e);
    return [];
  }
}

export function deleteDraft(id) {
  try {
    const drafts = getDrafts().filter(d => d.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(drafts));
    return drafts;
  } catch (e) {
    console.warn('删除草稿失败:', e);
    return [];
  }
}

export function clearAllDrafts() {
  try {
    localStorage.removeItem(STORAGE_KEY);
    return [];
  } catch (e) {
    console.warn('清空草稿失败:', e);
    return [];
  }
}

export function exportAsJSON(data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `resume_${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function importFromJSON(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = JSON.parse(e.target.result);
        resolve(data);
      } catch (err) {
        reject(new Error('Invalid JSON file'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}
