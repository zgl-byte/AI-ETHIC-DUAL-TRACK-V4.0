const patterns = {
  phone: /1[3-9]\d{9}/g,
  email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
  age: /([1-2]\d{3})年出生|(\d{2})岁/g,
  degree: /(博士|硕士|本科|专科|高中|中专)/g,
  school: /(大学|学院|学校|学院)/g,
  company: /(字节跳动|腾讯|阿里巴巴|美团|京东|百度|华为|小米|滴滴|拼多多|快手|抖音|哔哩哔哩|网易|新浪|搜狐|360|联想|OPPO|VIVO)/g,
  position: /(前端工程师|后端工程师|全栈工程师|产品经理|设计师|测试工程师|运维工程师|数据分析师)/g,
  salary: /(\d+)[kK]-(\d+)[kK]|期望薪资[：:]?\s*(\d+)-(\d+)/g,
  date: /(\d{4})[./年](\d{1,2})[月.]?/g,
};

const techKeywords = [
  'React', 'Vue', 'Angular', 'Node.js', 'Python', 'Java', 'Go', 'TypeScript',
  'JavaScript', 'CSS', 'HTML', 'Webpack', 'Vite', 'Git', 'Docker', 'Kubernetes',
  'AWS', 'Azure', 'MySQL', 'MongoDB', 'Redis', 'GraphQL', 'REST', 'API',
];

const actionVerbs = [
  '负责', '主导', '参与', '独立完成', '优化', '提升', '搭建', '构建',
  '设计', '开发', '实现', '维护', '改进', '推动', '带领', '管理',
];

export function parseRawText(raw) {
  const result = {
    name: '',
    phone: '',
    email: '',
    age: '',
    position: '',
    salary: '',
    summary: '',
    workExps: [],
    edus: [],
    projectExps: [],
    skills: '',
  };

  // 提取姓名（第一个汉字序列）
  const nameMatch = raw.match(/[\u4e00-\u9fa5]{2,4}(?=\s|$|，|。|、)/);
  if (nameMatch) result.name = nameMatch[0];

  // 提取手机号
  const phoneMatch = raw.match(patterns.phone);
  if (phoneMatch) result.phone = phoneMatch[0];

  // 提取邮箱
  const emailMatch = raw.match(patterns.email);
  if (emailMatch) result.email = emailMatch[0];

  // 提取年龄
  const ageMatch = raw.match(/([1-2]\d{3})年出生/);
  if (ageMatch) {
    const birthYear = parseInt(ageMatch[1]);
    result.age = String(new Date().getFullYear() - birthYear);
  } else {
    const ageNum = raw.match(/(\d{2})岁/);
    if (ageNum) result.age = ageNum[1];
  }

  // 提取期望职位
  const posMatch = raw.match(/期望(岗位|职位|工作)[：:]?\s*([^\s，,。]+)/i);
  if (posMatch) result.position = posMatch[2];
  else {
    const posMatch2 = raw.match(/(?:前端|后端|全栈|测试|运维|产品|设计)(?:工程师|经理|总监)?/);
    if (posMatch2) result.position = posMatch2[0];
  }

  // 提取期望薪资
  const salaryMatch = raw.match(/期望薪资?\s*(\d+)-(\d+)/);
  if (salaryMatch) result.salary = `${salaryMatch[1]}-${salaryMatch[2]}K`;

  // 提取联系方式后面的基本信息
  const sections = raw.split(/工作经历|项目经历|教育经历|专业技能|项目经验|实习经历/);
  
  // 工作经历
  for (let i = 1; i < sections.length; i++) {
    const section = sections[i];
    const nextSection = sections[i + 1] || '';
    
    if (raw.indexOf('工作经历') > 0 && section.indexOf('项目经历') < 0 && section.indexOf('教育经历') < 0) {
      const companies = section.split(/\n|；|;/).filter(s => s.trim().length > 10);
      companies.forEach(companyText => {
        const companyMatch = companyText.match(/在(.+?)(担任|任职|任职于)/);
        const positionMatch = companyText.match(/(担任|任职)(.+?)(，|,)/);
        const dateMatch = companyText.match(/(\d{4})[年./]?(\d{0,2})?\s*[-~至]\s*(\d{4})?[年./]?(\d{0,2})?/);
        
        result.workExps.push({
          id: Math.random().toString(36).substr(2, 9),
          company: companyMatch ? companyMatch[1] : '公司名待填写',
          position: positionMatch ? positionMatch[2] : '职位待填写',
          startDate: dateMatch ? `${dateMatch[1]}.${dateMatch[2] || '01'}` : '',
          endDate: dateMatch && dateMatch[3] ? `${dateMatch[3]}.${dateMatch[4] || '01'}` : '至今',
          description: companyText.substring(0, 200),
        });
      });
    }
    
    // 项目经历
    if (section.indexOf('项目') >= 0 && nextSection.indexOf('教育') >= 0) {
      const projects = nextSection.split(/\n|；|;/).filter(s => s.trim().length > 10);
      projects.forEach(projText => {
        const nameMatch = projText.match(/(.+?)(项目|系统|平台)/);
        result.projectExps.push({
          id: Math.random().toString(36).substr(2, 9),
          name: nameMatch ? nameMatch[0] : '项目名待填写',
          role: '开发',
          startDate: '',
          endDate: '',
          description: projText.substring(0, 200),
        });
      });
    }
  }

  // 提取教育经历
  const eduMatch = raw.match(/教育经历[：:]?\s*([\s\S]*?)(?=专业技能|项目|$)/i);
  if (eduMatch) {
    const eduText = eduMatch[1];
    const schoolMatch = eduText.match(/[\u4e00-\u9fa5]{2,10}(?:大学|学院|学校)/);
    const majorMatch = eduText.match(/(?:计算机|软件|信息|电子|机械|自动化|管理|经济|法律|设计|艺术)(?:工程|科学|技术|设计|管理|学)/);
    const degreeMatch = eduText.match(/(博士|硕士|本科|专科)/);
    const dateMatch = eduText.match(/(\d{4})\s*[-~至]\s*(\d{4})/);
    
    if (schoolMatch || majorMatch) {
      result.edus.push({
        id: Math.random().toString(36).substr(2, 9),
        school: schoolMatch ? schoolMatch[0] : '学校待填写',
        major: majorMatch ? majorMatch[0] : '专业待填写',
        degree: degreeMatch ? degreeMatch[1] : '本科',
        startDate: dateMatch ? dateMatch[1] : '',
        endDate: dateMatch ? dateMatch[2] : '',
      });
    }
  }

  // 提取专业技能
  const skillsMatch = raw.match(/(?:专业技能|技能特长)[：:]?\s*([\s\S]*?)$/i);
  if (skillsMatch) {
    result.skills = skillsMatch[1]
      .replace(/\n/g, ' ')
      .replace(/[,，;；]/g, ' / ')
      .trim();
  }

  // 如果没有提取到技能，尝试从全文提取技术关键词
  if (!result.skills) {
    const foundSkills = techKeywords.filter(keyword => 
      raw.toLowerCase().includes(keyword.toLowerCase())
    );
    if (foundSkills.length > 0) {
      result.skills = foundSkills.join(' / ');
    }
  }

  return result;
}

export function formatDescription(text) {
  // 优化描述格式
  let formatted = text
    .replace(/([。；])/g, '$1\n')
    .replace(/(\d+)秒/g, '$1秒')
    .replace(/(\d+)%/g, '$1%')
    .replace(/(\d+)万/g, '$1万')
    .replace(/(\d+)K/g, '$1K');
  
  // 确保每行以动词开头
  const lines = formatted.split('\n').filter(l => l.trim());
  return lines.map(line => {
    const trimmed = line.trim();
    if (!trimmed) return '';
    const hasVerb = actionVerbs.some(v => trimmed.startsWith(v));
    if (!hasVerb && trimmed.length > 10) {
      return '• ' + trimmed;
    }
    return hasVerb ? trimmed : '• ' + trimmed;
  }).join('\n');
}
